let posts = $.get('https://www.reddit.com/r/programmerhumor.json')

posts.done(function(data) {
  let post = data.data.children[randomNumber(data.data.children.length)].data;

  // console.log(post);


  let title = post.title;
  let image = post.url;

  console.log(title, image);
  $('.title').html(title);
  $('.reddit-img').attr('src', image);

})

function randomNumber(limit) {
  return Math.floor(Math.random() * limit);
}